Young Studio — Native (C / Win32)
=================================

Requisitos:
- Windows 10/11 (64-bit)
- Python 3.10+ instalado y en PATH (el runtime de .young todavia corre sobre
  young_runner.py; la UI y las llamadas a Claude si son nativas en C)
- Visual C++ Redistributable (x64) si Windows te avisa que falta una DLL:
  https://aka.ms/vs/17/release/vc_redist.x64.exe

Uso:
1. Descomprimir esta carpeta completa (no separar los archivos).
2. Doble click en run-young-studio.bat, o ejecutar young_studio.exe directo.
3. Configurar tu ANTHROPIC_API_KEY como variable de entorno para usar las
   pestañas Compose / Live (llamadas a Claude).

Incluye tambien young_haiku_cli.exe, un cliente de linea de comandos minimo
para probar la conexion con Claude:
    young_haiku_cli.exe "tu prompt"
