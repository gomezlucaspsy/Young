@echo off
if "%YOUNG_CLAUDE_MODEL%"=="" set "YOUNG_CLAUDE_MODEL=claude-haiku-4-5"
if "%YOUNG_MAX_TOKENS%"=="" set "YOUNG_MAX_TOKENS=256"
if "%YOUNG_TEMPERATURE%"=="" set "YOUNG_TEMPERATURE=0.3"

set "EXE=native\build\Release\young_studio.exe"
if not exist "%EXE%" set "EXE=native\build\Debug\young_studio.exe"
if not exist "%EXE%" (
    echo young_studio.exe not found. Run cmake --build native\build --config Release first.
    pause
    exit /b 1
)
start "" "%EXE%"
