Young Studio — Python / Tkinter
===============================

Requisitos:
- Python 3.10+ (Tkinter viene incluido en la instalacion estandar de Python
  en Windows/Mac; en Linux instala el paquete python3-tk de tu distro)

Uso:
1. Descomprimir esta carpeta completa (no separar los archivos).
2. Doble click en run-young-gui.bat (Windows), o correr:
       python young_gui.py
3. Configurar tu ANTHROPIC_API_KEY como variable de entorno para usar las
   funciones de Claude (Compose / Live Agent).

Tambien podes correr scripts .young directo desde la terminal:
    python young_runner.py sample_tarot.young

Ver README_YOUNG_ASSEMBLY.md para la guia completa del lenguaje.
